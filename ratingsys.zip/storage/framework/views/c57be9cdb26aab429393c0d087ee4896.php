<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>التوقيع الرقمي</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .sign-pad-button-submit {
      margin-top: 5px;
      background-color: #3b82f6;
      color: white;
      font-weight: bold;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      transition: background-color 0.3s ease;
    }
    .sign-pad-button-submit:hover {
      background-color: #2563eb;
    }
    .sign-pad-button-clear {
      margin-top: 5px;
      background-color: #ef4444;
      color: white;
      font-weight: bold;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      transition: background-color 0.3s ease;
    }
    .sign-pad-button-clear:hover {
      background-color: #dc2626;
    }
  </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center">
  <form action="<?php echo e(route('sign.managerconfirm')); ?>" method="POST" class="bg-white p-10 rounded-lg shadow-lg max-w-xl w-full">
    <?php echo csrf_field(); ?>
    
    <!-- Display Success Message -->
    <?php if(session('success')): ?>
    <div class="bg-green-100 text-green-700 p-4 rounded mb-4">
      <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <!-- Display Error Messages -->
    <?php if($errors->any()): ?>
    <div class="bg-red-100 text-red-700 p-4 rounded mb-4">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <input type="text" id="rating_id" name="rating_id" value="<?php echo e($rating->id); ?>" hidden/>
    </div>
    <!-- Signature Pad -->
    <div class="mb-4">
      <label class="block text-lg text-gray-700 font-medium mb-2">Signature</label>
      <?php if (isset($component)) { $__componentOriginald7073ca775bb7f1ffb43b06c4cc494e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7073ca775bb7f1ffb43b06c4cc494e3 = $attributes; } ?>
<?php $component = Creagia\LaravelSignPad\Components\SignaturePad::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('creagia-signature-pad'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Creagia\LaravelSignPad\Components\SignaturePad::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sign']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7073ca775bb7f1ffb43b06c4cc494e3)): ?>
<?php $attributes = $__attributesOriginald7073ca775bb7f1ffb43b06c4cc494e3; ?>
<?php unset($__attributesOriginald7073ca775bb7f1ffb43b06c4cc494e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7073ca775bb7f1ffb43b06c4cc494e3)): ?>
<?php $component = $__componentOriginald7073ca775bb7f1ffb43b06c4cc494e3; ?>
<?php unset($__componentOriginald7073ca775bb7f1ffb43b06c4cc494e3); ?>
<?php endif; ?>
    </div>
  </form>
  <!-- Sign-pad js -->
  <script src="<?php echo e(asset('vendor/sign-pad/sign-pad.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\MaenAlrefai\Herd\ratingsys\resources\views/signature/managersign.blade.php ENDPATH**/ ?>