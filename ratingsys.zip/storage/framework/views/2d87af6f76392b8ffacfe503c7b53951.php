<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($form->name ." - " . $teacher->name); ?></title>

    <style>
        table {
            border-collapse: collapse;
            max-width: 2480px;
            width:80%;
        }
        table td{
            width: auto;
            overflow: hidden;
            word-wrap: break-word;
        }
        @media print {
            body {
                zoom: 72%;
            }
            }
        .myTable {
            border: 3px solid black;
        }
            .center {
                margin-left: auto;
                margin-right: auto;
            }
            .myelement {
                clear:left;
                height:auto;
                margin: auto;
                font-size: 130%; // See below for explanation of this
            }
            .myelementt {
                font-size: 110%; // See below for explanation of this
            }

    </style>
</head>
<?php if($form->type == App\Enums\Formtype::Field): ?>
    <body class="center" style="width: 100%;  print-color-adjust: exact;" dir="rtl">
        <?php
            $a = 1;
        ?>
        <div class="center" style="border-style: solid solid solid solid; width: 80%;">
            <h3 style="text-align: center;"><?php echo e($form->name); ?></h3>
            <table class="center myTable">
                <tr>
                    <th class="myTable" width="1%" style="background-color: #d9d9d9;">م</th>
                    <th class="myTable" width="65%" style="font-size: 120%; background-color: #d9d9d9;"><p><strong>الكفايات</strong></p></th>
                    <?php if($form->type == App\Enums\Formtype::Field): ?>
                        <?php $__currentLoopData = $allEstimates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="myTable" width="10%" style="font-size: 120%; background-color: #d9d9d9;"><?php echo e($estimate->name); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                    <?php if($form->type == App\Enums\Formtype::Field): ?>
                        <?php $__currentLoopData = $options["fields"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $allFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($field_id == $field->id): ?>
                                    <tr>
                                        <td class="myTable" colspan="7" style="font-size: 115%; background-color: #d9d9d9;">
                                            <strong><?php echo e($field->name); ?></strong>
                                        </td>
                                    </tr>
                                    <?php $__currentLoopData = $field->competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="myTable" style="background-color: #d9d9d9;">
                                            <?php echo e($a++); ?>

                                        </td>
                                        <td class="myTable" style="font-size: 105%;"><b></b><?php echo e($comp->name); ?></td>
                                        <?php $__currentLoopData = $allEstimates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="myTable" style="text-align: center;">
                                                <?php $__currentLoopData = $data["estimate"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($comp->id == $key && $estimate->id == $est): ?>
                                                    &#10004;
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            </table>


        </div>
        <br><br>
        <div class="center" style="border-style: solid solid solid solid; width: 80%;">
            <br><br>
            <div class="center" style="border-style: solid solid solid solid; width: 80%;">
                <table>
                    <td>
                        <?php if($data["dayanddate"] != null): ?>
                        &nbsp;<strong class="myelement"> اليوم والتاريخ:</strong>&nbsp;&nbsp;&nbsp;&nbsp;<b class="myelement"><?php echo e($data["day"]); ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($data["dayanddate"]); ?></b>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($data["level"] != null): ?>
                        <strong class="myelement"> المستوى:</strong>&nbsp;&nbsp;<b class="myelement"><?php echo e($data["level"]); ?></b>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($data["childrencount"] != null): ?>
                        <strong class="myelement center"> عدد الأطفال:</strong>&nbsp;&nbsp;<b class="myelement"><?php echo e($data["childrencount"]); ?></b>
                        <?php endif; ?>
                    </td>
                </table>
                <br>
                <table>
                    <td>
                        <?php if($data["eduexp"] != null): ?>
                        &nbsp;<strong class="myelement"> الخبرة التربوية:</strong>&nbsp;&nbsp;<b class="myelement"><?php echo e($data["eduexp"]); ?></b>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($data["week"] != null): ?>
                        <strong class="myelement"> الاسبوع:</strong>&nbsp;&nbsp;<b class="myelement"><?php echo e($data["week"]); ?></b>
                        <?php endif; ?>
                    </td>
                    <td >
                        <?php if($data["period"] != null): ?>
                        <strong class="myelement center"> الفترة:</strong>&nbsp;&nbsp;<b class="myelement"><?php echo e($data["period"]); ?></b>
                        <?php endif; ?>
                        <?php if($data["activitytype"] != null): ?>
                        <strong class="myelement center"> نوع النشاط:</strong>&nbsp;&nbsp;<b class="myelement"><?php echo e($data["activitytype"]); ?></b>
                        <?php endif; ?>
                    </td>
                </table>
                <br>
                <table>
                    <td style="width: 100%;">
                        <?php if($data["general"] != null): ?>
                        <strong class="myelement"> الهدف العام:</strong>&nbsp;&nbsp;<b class="myelement"><?php echo e($data["general"]); ?></b>
                        <?php endif; ?>
                    </td>
                </table>
                <br>
                <table>
                    <td style="width: 100%;">
                        <?php if($data["goals"] != null): ?>
                        <strong class="myelement" style="font-size: 150%;"> الأهداف السلوكية:</strong><br><br><b class="myelement"><?php echo e($data["goals"]); ?></b>
                        <?php endif; ?>
                    </td>
                </table>
            </div>
            <br>
            <br>
            <?php if($data["activityshow"] != null): ?>
                <div style="width: 80%;">
                    <table>
                        <tr>
                            <td>

                                    <strong class="myelement" style="font-size: 150%; margin-right: 10px;"> أسلوب عرض النشاط:</strong>

                            </td>
                        </tr>
                        <tr>
                            <td style="height: 150px">
                                <p class="myelement" style="margin-right: 10px;"><?php echo e($data["activityshow"]); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            <?php endif; ?>

            <?php if($data["activitygoals"] != null): ?>
                <div style="width: 80%;">
                    <table>
                        <tr>
                            <td>

                                    <strong class="myelement" style="font-size: 150%; margin-right: 10px;"> الأهداف التي تم تحقيقها من خلال النشاط:</strong>

                            </td>
                        </tr>
                        <tr>
                            <td style="height: 150px">
                                <p class="myelement" style="margin-right: 10px;"><?php echo e($data["activitygoals"]); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            <?php endif; ?>
            <div class="center" style="width: 80%;">
                <table class="center">
                    <tr>
                        <th>
                            <?php if($data["report"] != null): ?>
                                <strong class="myelement" style="font-size: 150%;"> تقرير وصفي مختصر:</strong>
                            <?php endif; ?>
                        </th>
                    </tr>
                    <tr>
                        <td style="height: 150px">
                            <p class="myelement"><?php echo e($data["report"]); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="width: 80%;">
                <table>
                    <tr>
                        <td>
                            <?php if($data["note"] != null): ?>
                                <strong class="myelement" style="font-size: 150%; margin-right: 10px;"> الملاحظات:</strong>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 150px">
                            <p class="myelement" style="margin-right: 10px;"><?php echo e($data["note"]); ?></p>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="center" style="width: 100%;">
                <table class="center">
                    <tr>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المعلمة</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المشرفة الفنية</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المديرة</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع الموجهة الفنية</strong>
                        </th>
                    </tr>
                    <tr>
                        <th>
                            <?php if($teachersign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $teachersign->signature->filename)); ?>" alt="توقيع المعلمة" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($user): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $user->signature->filename)); ?>" alt="توقيع المشرفة الفنية" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($managersign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $managersign->signature->filename)); ?>" alt="توقيع المديرة" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($directorsign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $directorsign->signature->filename)); ?>" alt="توقيع الموجهة الفنية" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>
                    </tr>
                </table>
            </div>
        </div>
    </body>
<?php endif; ?>
<?php if($form->type == App\Enums\Formtype::Activity): ?>
    <body class="center" style="width: 100%;  print-color-adjust: exact;" dir="rtl">
        <br><br><br>
        <div class="center" style="border-style: solid solid solid solid; width: 80%;">
            <br><br><br>
                <table class="center" style="border-style: solid solid solid solid; width: 95%;">
                    <tr style="background-color: #d9d9d9; "><th colspan="5" style="background-color: #d9d9d9; width: 95%;"><h3 style="text-align: center;"><?php echo e($form->name); ?></h3></th></tr>
                    <tr>
                        <th style="border-style: solid solid solid solid;"><strong class="myelement">اليوم والتاريخ</strong></th>
                        <th style="border-style: solid solid solid solid;"><strong class="myelement">اسم المعلمة</strong></th>
                        <th style="border-style: solid solid solid solid;"><strong class="myelement">المستوى - عدد الأطفال</strong></th>
                        <th style="border-style: solid solid solid solid;"><strong class="myelement">الخبرة التربوية - الأسبوع</th>
                        <th style="border-style: solid solid solid solid;"><strong class="myelement">اسم المهارة</strong></th>
                    </tr>
                    <tr>
                        <td style="text-align: center;border-style: solid solid solid solid;">
                            <?php if($data["dayanddate"] != null): ?>
                            <b class="myelement"><?php echo e($data["day"]); ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($data["dayanddate"]); ?></b>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;border-style: solid solid solid solid;">
                            <?php if($data["teachername"] != null && $data["teachername"] == 1 ): ?>
                            <b class="myelement"><?php echo e($teacher->name); ?></b>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;border-style: solid solid solid solid;">
                            <?php if($data["level"] != null): ?>
                            <b class="myelement"><?php echo e($data["level"]); ?>

                                -
                                <?php if($data["childrencount"] != null): ?>
                                <?php echo e($data["childrencount"]); ?>

                                <?php endif; ?>
                            </b>
                            <?php endif; ?>

                        </td>
                        <td style="text-align: center; border-style: solid solid solid solid;">
                            <b class="myelement">
                            <?php if($data["eduexp"] != null): ?>
                            <?php echo e($data["eduexp"]); ?>

                                -


                            <?php endif; ?>
                            <?php if($data["week"] != null): ?>
                                <?php echo e($data["week"]); ?>

                            <?php endif; ?>
                        </b>
                        </td>
                        <td style="text-align: center; border-style: solid solid solid solid;">
                            <?php if($data["skillname"] != null): ?>
                            <b class="myelement"><?php echo e($data["skillname"]); ?></b>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <br><br><br>
            <table class="center myTable" style="width: 95%;">
                <tr>
                    <th class="myTable" width="10%" style="background-color: #d9d9d9; ">أجزاء الدرس</th>
                    <th class="myTable" width="30%" style="font-size: 120%; background-color: #d9d9d9;"><p><strong>الكفايات</strong></p></th>
                    <?php if($form->type == App\Enums\Formtype::Activity): ?>
                        <?php $__currentLoopData = $allEstimatesgraded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="myTable" width="60px" style="font-size: 120%; background-color: #d9d9d9;"><?php echo e($estimate->name); ?> <br> <?php echo e("(". $estimate->grade.")"); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                    <?php if($form->type == App\Enums\Formtype::Activity): ?>
                        <?php $__currentLoopData = $options["activities"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $allActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($activity_id == $activity->id): ?>
                                    <tr>
                                        <td rowspan="<?php echo e(count($activity->competences)+1); ?>" class="myTable" style="font-size: 115%; background-color: #d9d9d9; text-align: center;">
                                            <strong><?php echo e($activity->name); ?><br><?php echo e("(" . $activity->grade .")"); ?></strong>
                                        </td>
                                    </tr>
                                    <?php $__currentLoopData = $activity->competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="myTable" style="font-size: 105%;"><b></b><?php echo e($comp->name); ?></td>
                                        <?php $__currentLoopData = $allEstimatesgraded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="myTable" style="text-align: center;">
                                                <?php $__currentLoopData = $data["estimate"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($comp->id == $key && $estimate->id == $est): ?>
                                                    &#10004;
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            </table>


        </div>
        <br><br><br><br>
        <div class="center" style="border-style: solid solid solid solid; width: 80%;">

            <div style="width: 80%;">
                <table>
                    <tr>
                        <td>
                            <?php if($data["note"] != null): ?>
                                <strong class="myelement" style="font-size: 150%; margin-right: 10px;"> الملاحظات:</strong>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 150px">
                            <p class="myelement" style="margin-right: 10px;"><?php echo e($data["note"]); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="width: 80%;">
                <table>
                    <tr>
                        <td>
                            <?php if($data["recommendations"] != null): ?>
                                <strong class="myelement" style="font-size: 150%; margin-right: 10px;"> التوصيات:</strong>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 150px">
                            <p class="myelement" style="margin-right: 10px;"><?php echo e($data["recommendations"]); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <div class="center" style="width: 100%;">
                <table class="center">
                    <tr>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المعلمة</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المشرفة الفنية</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المديرة</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع الموجهة الفنية</strong>
                        </th>
                    </tr>
                    <tr>
                        <th>
                            <?php if($teachersign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $teachersign->signature->filename)); ?>" alt="توقيع المعلمة" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($user): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $user->signature->filename)); ?>" alt="توقيع المشرفة الفنية" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($managersign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $managersign->signature->filename)); ?>" alt="توقيع المديرة" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($directorsign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $directorsign->signature->filename)); ?>" alt="توقيع الموجهة الفنية" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>
                    </tr>
                </table>
            </div>
        </div>
    </body>
<?php endif; ?>
<?php if($form->type == App\Enums\Formtype::Competence): ?>
    <body class="center" style="width: 100%;  print-color-adjust: exact;" dir="rtl">
        <?php
            $a = 1;
        ?>
        <div class="center" style="border-style: solid solid solid solid; width: 80%;">
            <br><br><br>
                <table class="center" style="border-style: solid solid solid solid; width: 95%;">
                    <tr style="background-color: #d9d9d9; "><th colspan="5" style="background-color: #d9d9d9; width: 95%;"><h3 style="text-align: center;"><?php echo e($form->name); ?></h3></th></tr>
                    <tr>
                        <th><strong class="myelementt">اليوم والتاريخ: </strong>&nbsp;                            <?php if($data["dayanddate"] != null): ?>
                            <b class="myelementt"><?php echo e($data["day"]); ?>&nbsp;<?php echo e($data["dayanddate"]); ?></b>
                            <?php endif; ?>
                        </th>
                        <th><strong class="myelementt">اسم المعلمة: </strong>&nbsp;                            <?php if($data["teachername"] != null && $data["teachername"] == 1 ): ?>
                            <b class="myelementt"><?php echo e($teacher->name); ?></b>
                            <?php endif; ?>
                        </th>
                        <th><strong class="myelementt">المستوى: </strong>&nbsp;<?php if($data["level"] != null): ?>
                            <b class="myelementt"><?php echo e($data["level"]); ?> </b>
                            <?php endif; ?></th>
                        <th><strong class="myelementt">عدد الأطفال: </strong>&nbsp;<?php if($data["childrencount"] != null): ?>

                            <b class="myelementt"><?php echo e($data["childrencount"]); ?></b>

                            <?php endif; ?></th>
                    </tr>
                    <tr>
                        <th><strong class="myelementt">الخبرة التربوية:  </strong>&nbsp;<?php if($data["eduexp"] != null): ?>
                            <?php echo e($data["eduexp"]); ?> <?php endif; ?>
                        </th>
                        <th><strong class="myelementt">الاسبوع:  </strong>&nbsp;<?php if($data["week"] != null): ?>
                            <?php echo e($data["week"]); ?>

                        <?php endif; ?>
                        </th>
                        <th colspan="2"><strong class="myelementt">اسم القصة أو الفيلم التعليمي:  </strong>&nbsp;<?php if($data["filmname"] != null): ?>
                            <b class="myelementt"><?php echo e($data["filmname"]); ?></b>
                            <?php endif; ?>
                        </th>
                    </tr>

                </table>
                <br><br><br><br><br><br>
            <table class="center myTable" style="width: 95%;">
                <tr>
                    <th class="myTable" width="1%" style="background-color: #d9d9d9;">م</th>
                    <th class="myTable" width="65%" style="font-size: 120%; background-color: #d9d9d9;"><p><strong>الكفايات</strong></p></th>
                    <?php if($form->type == App\Enums\Formtype::Competence): ?>
                        <?php $__currentLoopData = $allEstimates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="myTable" width="10%" style="font-size: 120%; background-color: #d9d9d9;"><?php echo e($estimate->name); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                    <?php if($form->type == App\Enums\Formtype::Competence): ?>
                        <?php $__currentLoopData = $options["competences"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competence_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $allCompetences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competences): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($competence_id == $competences->id): ?>
                                    <tr>
                                        <td class="myTable" style="background-color: #d9d9d9;">
                                            <?php echo e($a++); ?>

                                        </td>
                                        <td class="myTable" style="font-size: 115%;">
                                            <strong><?php echo e($competences->name); ?></strong>
                                        </td>
                                        <?php $__currentLoopData = $allEstimates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="myTable" style="text-align: center;">
                                                <?php $__currentLoopData = $data["estimate"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($competences->id == $key && $estimate->id == $est): ?>
                                                    &#10004;
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            </table>

        <br><br><br><br>


            <div style="width: 80%;">
                <table>
                    <tr>
                        <td>
                            <?php if($data["note"] != null): ?>
                                <strong class="myelement" style="font-size: 150%; margin-right: 10px;"> الملاحظات:</strong>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 150px">
                            <p class="myelement" style="margin-right: 10px;"><?php echo e($data["note"]); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="width: 80%;">
                <table>
                    <tr>
                        <td>
                            <?php if($data["recommendations"] != null): ?>
                                <strong class="myelement" style="font-size: 150%; margin-right: 10px;"> التوصيات:</strong>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 150px">
                            <p class="myelement" style="margin-right: 10px;"><?php echo e($data["recommendations"]); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            <br><br><br><br>
            <div class="center" style="width: 100%;">
                <table class="center">
                    <tr>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المعلمة</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المشرفة الفنية</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع المديرة</strong>
                        </th>
                        <th>
                            <strong class="myelement" style="font-size: 150%;">توقيع الموجهة الفنية</strong>
                        </th>
                    </tr>
                    <tr>
                        <th>
                            <?php if($teachersign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $teachersign->signature->filename)); ?>" alt="توقيع المعلمة" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($user): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $user->signature->filename)); ?>" alt="توقيع المشرفة الفنية" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($managersign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $managersign->signature->filename)); ?>" alt="توقيع المديرة" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>

                        <th>
                            <?php if($directorsign): ?>
                                <img width="100" height="100" src="<?php echo e(asset('storage/' . $directorsign->signature->filename)); ?>" alt="توقيع الموجهة الفنية" class="w-full h-auto">
                            <?php else: ?>
                                <p>لايوجد توقيع</p>
                            <?php endif; ?>
                        </th>
                    </tr>
                </table>
            </div>
        </div>
    </body>
<?php endif; ?>
</html>
<?php /**PATH C:\Users\MaenAlrefai\Herd\ratingsys\resources\views/rating/show.blade.php ENDPATH**/ ?>