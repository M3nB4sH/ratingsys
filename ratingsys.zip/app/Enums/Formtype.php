<?php

namespace App\Enums;

enum Formtype : string
{
    case Activity = 'activity';
    case Field = 'field';

    case Competence = 'competence';

}
