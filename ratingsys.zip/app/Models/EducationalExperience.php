<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EducationalExperience extends Model
{
    protected $fillable = ['name', 'is_deleted'];
}
