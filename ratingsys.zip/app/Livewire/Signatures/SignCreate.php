<?php

namespace App\Livewire\Signatures;

use Livewire\Component;

class SignCreate extends Component
{
    // public $sign;
    public function render()
    {

        return view('livewire.signatures.sign-create');
    }
}
