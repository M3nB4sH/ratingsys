<?php

namespace App\Livewire\Signatures;

use Livewire\Component;

class SignIndex extends Component
{
    public function render()
    {
        return view('livewire.signatures.sign-index');
    }
}
